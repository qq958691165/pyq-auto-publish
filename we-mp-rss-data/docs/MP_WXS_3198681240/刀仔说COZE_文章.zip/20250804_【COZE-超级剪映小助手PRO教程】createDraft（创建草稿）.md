# 【COZE-超级剪映小助手PRO教程】createDraft（创建草稿）

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfia2zBibk1fNI4DsTPk1OWnzAM811rr2A59Q7mJ87uR6CYmL5hW4Qdlwxw/640?wx_fmt=png&from=appmsg)

该工具为剪映草稿之根本，只需输入你想要的视频的高和宽（以像素为单位，示例：高height为1920，宽width为1080）

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaddicKhBYRcDAKE8OaKBQz15V5Z5pBFcaX7ic560NrW2fK4JBMhBM37GQ/640?wx_fmt=png&from=appmsg)

运行后即可获得一个draft\_url(草稿地址）

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaTfVdtiatcuhoeOIxnKyRh659klUrzuHMfytMOXAJZXnibMmOrRmUcj6A/640?wx_fmt=png&from=appmsg)

draft\_url用于传输给后续所有需要此参数的工具使用。

友情提示

由于剪映工具箱和数据项工具较多，且需要搭配使用，建议先将这两个插件进行收藏，方便使用

收藏方法：

1.点击添加节点-插件

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaZhSEcYTJWRVd0wVx9diar7H5hsgMoPQ64s0OpSMfsf3xtnPiaiabhZib5Q/640?wx_fmt=png&from=appmsg)

2.搜索“智界”，如图所示

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaiaiagucGTp9ZKQaycIib6SnX36MaAWz87js1D1dYjj9ZwkBicDzSv4geMQ/640?wx_fmt=png&from=appmsg)

3.鼠标悬停插件上方，出现“进入”按钮，点击进入

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfia8KBpEGjUIEibiacmJWsVfy6ziaJwMetTPsN99EIAZfhxsYAAZBWJCJN2Q/640?wx_fmt=png&from=appmsg)

4.点击右上角“收藏”

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaO4JXk1cJ5En2Ym98lJApfvS0v0fNn91w5yD1uY9MqKQFhYcic1b6qSA/640?wx_fmt=png&from=appmsg)

5.回到工作流界面，再次点击添加节点，即可看到收藏的插件。每次添加工具，从此页面点击插件即可。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiavnk6NcUJYIYXfqCECkhJH0DlAhRXhzGrwk1shD8abhAvOurmm36tSw/640?wx_fmt=png&from=appmsg)