# 【COZE-超级剪映小助手PRO】timelines_pro（智能时间线工具）

标题一、二讲的基本原理。

一、什么是时间线

通俗的讲，时间线就是剪映的素材轨道。也可以理解为放置素材的容器或者丈量素材的标尺。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaoL32My7opd0IMKoIbYFd6IgmS1nq79LHpqV59znpGevMNtibkPCLibwg/640?wx_fmt=png&from=appmsg)

轨道上的素材有视频、音频、字幕、特效、贴纸、音效。每个素材在轨道上的位置、长短，都由timelines（all\_timelines）时间线来决定（  后续每个添加素材的工具都要用到这个工具输出的参数  ）。

# 二、timelines和all\_timelines的区别

-打个比方，你生成了5段视频，需要分开排列、顺序摆放在轨道上，需要用到5个容器。timelines就是这五个容器。

-它记录每段视频在时间线（轨道）上的起始（start)和终止(end)的时间点（以微秒为单位）。

-适用场景：多段素材，如实时字幕、视频、音效等。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaya8rmFrzRaUeCohHYsg7PRT5sK8ZgSN5G8Cqw9aTibiaEsiakc9JXVGzA/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaHKfcvs5kYnPkictqrxurBpduAXFanxaicQtfSXMOInRnZNdtj9ozJdnQ/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaQic5gYIcDK1XO9RSeIFluYS1wQvyYFHzOTzq3hXzuUxnicDzHfGA36jg/640?wx_fmt=png&from=appmsg)

那all\_timelines就是这五个容器的总长。

适用场景：BGM、标题LOGO形式的字幕，与多段素材的尾帧对齐。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaqI4F7ORkBibzo240CgbAv9xibakhclHpDkOOAmhKnVeZWNgCZDYHkbqA/640?wx_fmt=png&from=appmsg)

当你在使用时间线工具时，会自动生成timelines和all\_timelines，按需选用。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiahk9ns6g0Hk0RI2ZZXPlQdJEbHrZEK7OlSz69E0JKUPqg558osGCBcg/640?wx_fmt=png&from=appmsg)

# 三、如何生成时间线

## 1.使用说明

timelines\_pro（智能时间线工具）

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaFdXichTnW4g2LkxyEP1LZhhW2zkdkDtDBNcqKXaSmnAaU9UsmbBKlcQ/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaOrkpRSKVezC3mA0k7T7afhVOFeWQuhhxQfPM9hpcmJsZ9eIZuz0bibw/640?wx_fmt=png&from=appmsg)

根据用户输入的数据，智能识别时间线。支持根据音频制作时间线和自定义时间线两种模式。两种模式只可选择一种，填入对应的参数。

## 2.参数说明

| 变量名 | 参数说明 | 参数类型 | 必填/选填 | 单位 | 示例 | 默认值 |
| --- | --- | --- | --- | --- | --- | --- |
| audio\_urls | 数组类型的音频URL地址 | array<string> | 选择根据音频文件制作时间线模式时必填 | - | - | - |
| duration | 时间线的总时长 | integer | 选择自定义时间线模式时必填 | 微秒（1秒=1000000微秒） | 1000000 | - |
| num | 时间线的分段数量 | integer | 选择自定义时间线模式时必填 | - | 5 | - |
| start | 时间线的起始时间点 | integer | 选择自定义模式时选填 | 微秒（1秒=1000000微秒） | 1000000 | 0 |

## 3.使用示例

### （1）根据音频制作时间线模式

该模式自动识别音频文件的每个时长，适用于字幕、视频与音频轨道对齐的场景。

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiadwmF3K9owcvUMACfhu85IYKRNm8ZxO4n97NSUMYmgNfKoPssuSvyTw/640?wx_fmt=png&from=appmsg)

输入：

```python
["https://lf-bot-studio-plugin-resource.coze.cn/obj/bot-studio-platform-plugin-tos/artist/image/cfecea10e77e4488a6985db5a2f9a40d.mp3","https://lf-bot-studio-plugin-resource.coze.cn/obj/bot-studio-platform-plugin-tos/artist/image/a405eaf1bab24fdab8d10cbe95db4eb0.mp3","https://lf-bot-studio-plugin-resource.coze.cn/obj/bot-studio-platform-plugin-tos/artist/image/855d9d6a71574e0c9da4dc79006ff4f0.mp3","https://lf-bot-studio-plugin-resource.coze.cn/obj/bot-studio-platform-plugin-tos/artist/image/6a2e4051886440199ef8bce75df486b9.mp3","https://lf-bot-studio-plugin-resource.coze.cn/obj/bot-studio-platform-plugin-tos/artist/image/da5317d3b4b2406290bac6841e3e7ba0.mp3"]
```

就可以得到：

```python
{"all_timelines": [{"end": 26688000,"start": 0}],"timelines": [{"end": 5136000,"start": 0},{"end": 9648000,"start": 5136000},{"end": 13824000,"start": 9648000},{"end": 22992000,"start": 13824000},{"end": 26688000,"start": 22992000}]}
```

### （2）自定义时间线模式

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaBpkjsXlN8eicj08gnibbHRrhOuxGZianWK2iaQwSCglx97Q6WJuPZN7r3w/640?wx_fmt=png&from=appmsg)

输入：

```python
{"duration": 10000000,"num": 5,"start": 1000000}
```

就可以得到：

```python
{"all_timelines": [{"end": 11000000,"start": 1000000}],"timelines": [{"end": 3000000,"start": 1000000},{"end": 5000000,"start": 3000000},{"end": 7000000,"start": 5000000},{"end": 9000000,"start": 7000000},{"end": 11000000,"start": 9000000}]}
```