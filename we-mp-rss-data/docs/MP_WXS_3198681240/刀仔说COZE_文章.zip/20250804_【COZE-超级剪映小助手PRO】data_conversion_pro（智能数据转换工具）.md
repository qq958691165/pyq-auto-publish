# 【COZE-超级剪映小助手PRO】data_conversion_pro（智能数据转换工具）

智能识别数据类型，支持三种类型的数据转换

# 1.使用说明

智能识别数据类型，支持三种类型的数据转换：

- string转array<string>
- array<string>转array<object>
- array<object>转array<string>

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfiaRJd6DqFEtgcc8BDAth89ZvEGv5vF6DLicEVALN2XfhCESp1b5PvjwAg/640?wx_fmt=png&from=appmsg)

![](https://mmbiz.qpic.cn/sz_mmbiz_png/ZYicUtkicLESJQvH4QUyvOjWl9ibXAiaiccfialPB4tvSswaWNJNXkFY30mplBw4ia5QmoNzkmBgYlHbbFV3y0xsOP2TQ/640?wx_fmt=png&from=appmsg)

# 2.参数说明

| 变量名 | 参数说明 | 参数类型 | 必填/选填 | 单位 | 示例 | 默认值 |
| --- | --- | --- | --- | --- | --- | --- |
| objects\_to\_string\_list | array<obeject>转array<string> | array<obeject> | 选填 | - | - | - |
| string\_list\_to\_objects | array<string>转string | array<string> | 选填 | - | - | - |
| string\_to\_list | string转array<string> | string | 选填 | - | - | - |

# 3.使用示例

入参：

这里以把所有参数都输入进去作为示例，实际想用哪个功能就输入对应的参数就行，全部都是选填项

- objects\_to\_string\_list:[{"output":"1234"}]
- string\_list\_to\_objects:["1234"]
- string\_to\_list:1234

出参：

- objects\_to\_string\_list: ["1234"]
- string\_list\_to\_objects: [{"output": "1234"}]
- string\_to\_list: ["1234"]